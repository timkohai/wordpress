(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: If client supports jQuery we will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 */

})( jQuery );


// (function() {

	/**
	 * No Jquery - All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 */

// })();
